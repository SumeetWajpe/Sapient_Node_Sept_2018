var x =1000;
var boolvar = false;

/* This comment will not appear in the minified file ! */

function Addition(averyLongXvar,aVeryLongYvar){
    return averyLongXvar + aVeryLongYvar;
}