var buff = new Buffer('Sample Data to Be written in buffer !');
// console.log(buff);
console.log(buff.toString());
console.log(buff.toString('utf-8'));
console.log(buff.toString('base64'));
console.log(buff.length);

 var buffWithSize = new Buffer(250);
 var len = buffWithSize.write("Hello Buffer !");
 console.log('Length written : ' + len);
 console.log('Total size : ' + buffWithSize.length);

 var buffer1 = new Buffer('This is first line of string !');
 var buffer2 = new Buffer('This is second line of string !');

 var buffer3 = Buffer.concat([buffer1,buffer2]);
 console.log(buffer3.toString());

