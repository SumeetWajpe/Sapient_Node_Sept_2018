var fs = require('fs');

var readableStream = fs.createReadStream("Input.txt");
var writableStream = fs.createWriteStream("Output.txt");


// var allData = '';

// fired whenever emit('data') is called by fs !
// readableStream.on('data',function(chunk){
//    allData +=chunk;
// });

// // fired whenever emit('end') is called by fs !
// readableStream.on('end',function(){
//     writableStream.write(allData.toString());
//     writableStream.end();
// });


// OR

//readableStream.pipe(writableStream);


console.log('Program ended !');