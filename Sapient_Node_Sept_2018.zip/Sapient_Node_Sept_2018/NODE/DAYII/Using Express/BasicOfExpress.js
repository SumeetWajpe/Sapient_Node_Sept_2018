var express = require('express');
var bodyParser =require('body-parser');
var app = express();

var router = express.Router();

router.route('/products/:name').get(function(req,res){
          var products = [
        {name:'Mobile',price:20000},
        {name:'LED TV',price:30000},
        {name:'Laptop',price:50000}
    ];
    // read the paramters from the url !
    var pName = req.params.name;

       
                console.log('User requested for  : ' + pName);    
                var theProduct = products.find((p) => p.name == pName );
                
        if(theProduct){
            res.json(theProduct);        
        }else{
            res.json(products);
        }    
});


app.use('/',router); // express knows how to add the router
app.use(bodyParser.urlencoded({
    extended:true
}));
app.get('/',(req,res)=>{
    // res.send("<h1> Hello Express !</h1>");
    // res.sendFile("Index.html",{root:__dirname})
    
    // var products = [
    //     {name:'Mobile',price:20000},
    //     {name:'LED TV',price:30000},
    //     {name:'Laptop',price:50000}
    // ]
    // res.set("Content-Type","application/json");// Change Headers !
    // res.json(products);

    res.sendFile("Index.html",{root:__dirname})

});

app.post('/login',function(req,res){
    console.log(req.body.username);
    console.log(req.body.password);
    res.send("success");
});

app.use(function(req,res){
        res.statusCode = 404;
        res.sendFile("ErrorPage.html",{root:__dirname});
})

app.listen(3000,()=>{
    console.log('Server running at 3000 !')
});