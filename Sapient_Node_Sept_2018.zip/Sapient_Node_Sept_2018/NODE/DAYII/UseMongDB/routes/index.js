var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/products', function(req, res, next) {  

  // connect to MongoDB
  // MongoClient   -> mongodb package !
  // get the records from the DB
  // pass the collection of records to view to render !
  
  // 1. get the connection string !
  var url = "mongodb://localhost:27017";
  var MongoClient = mongodb.MongoClient;  
  MongoClient.connect(url,{useNewUrlParser:true},(err,db)=>{
      if(err){
        console.log(err)
      }else{
        console.log(db);
        var collection = db.db("products").collection("productlist");
        // Find all records
        collection.find({}).toArray((err,result)=>{
            if(err){
              console.log(err);
            }else if(result.length){
              // res.json(result);
              res.render('products',{ allProducts: result} );
            }
        })
      }
  })  
//  res.render('products',{} );
});

module.exports = router;
