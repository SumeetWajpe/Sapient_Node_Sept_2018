var express = require('express');
var router = express.Router();

router.route('/products').get(function(req,res){
    var products = [
  {name:'Mobile',price:20000},
  {name:'LED TV',price:30000},
  {name:'Laptop',price:50000}
];   
      res.render("Index",{message:"Rendered using Pug Engine !"});            
});

module.exports = router;