var express = require('express');
var app = express();
var router = require('./routes/products');
var path = require('path');

//set the view engine
app.set('views',path.join(__dirname,"views"));
app.set('view engine','pug');

app.use('/',router); 

app.get('/',function(req,res){
        res.send("Use routers for the output !")
});
app.use(function(req,res){
    res.statusCode = 404;
    res.sendFile("ErrorPage.html",{root:__dirname});
});
app.listen(3000,()=>{
console.log('Server running at 3000 !')
});
