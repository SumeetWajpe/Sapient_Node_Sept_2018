var request = require('request');

var fs = require('fs');

var response = "";
var evtEmtr = request('http://www.google.com');
evtEmtr.on('data',function(chunkOfData){
    response += chunkOfData + " >>>>>>>>>>>>>>>>>> DATA >>>>>>>>>>>>>>>>>>>>" ;
});

evtEmtr.on('error',function(err){
    console.log(err)
});

evtEmtr.on('end',function(){
    console.log('\n\nRequest ended !\n\n');
    fs.writeFile('MyGoogleResponse.html',response);
})