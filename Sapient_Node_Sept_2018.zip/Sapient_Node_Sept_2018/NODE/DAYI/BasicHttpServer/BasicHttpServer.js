var http = require('http');
var fs = require('fs');
var server = http.createServer(function(req,res){
      
    fs.readFile('Index.html',(err,dataFromFile)=>{
            if(err){

            }else if(dataFromFile){
                res.setHeader("Content-Type","text/html")
                    res.end(dataFromFile.toString());
            }
    })
    
});

server.listen(3000,function(){
    console.log('Server listening on port 3000 !');
});