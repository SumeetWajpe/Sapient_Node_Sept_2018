var fs = require('fs');

fs.readFile('Data.txt',function(err,dataFromFile){
    if(err){
        console.log('Error : ' + err);
    }else{
        console.log('Reading the file async : ' + dataFromFile.toString());
    }
});

var content = fs.readFileSync('Data.txt',"UTF-8");
console.log(content.toString());

console.log('Program Ended !');