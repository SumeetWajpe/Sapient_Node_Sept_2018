function Add(x,y){
    return x + y;
}
var Multiplication = (x,y)=> x * y

var PI = 3.14;

module.exports = {
    Addition:Add,
    Product:Multiplication,
    PIE:PI
}