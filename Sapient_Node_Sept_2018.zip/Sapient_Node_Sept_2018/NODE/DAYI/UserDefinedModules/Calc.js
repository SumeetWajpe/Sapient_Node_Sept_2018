var prod = require('./Math').Product;

console.log(prod(20,30));